/** Automatically generated file. DO NOT MODIFY */
package com.v2ex.v2droid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}