/** Automatically generated file. DO NOT MODIFY */
package de.neofonie.mobile.app.android.widget.crouton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}